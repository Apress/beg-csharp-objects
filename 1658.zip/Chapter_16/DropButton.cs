using System;
using System.Windows.Forms;
using System.Drawing;

public class DropButton {
  static void Main() {
    MessageBox.Show("You clicked the Drop button", "Button Clicked",
            MessageBoxButtons.OK, MessageBoxIcon.Information);
  }
}
