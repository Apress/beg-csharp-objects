// TestForm3Driver.cs

using System;
using System.Windows.Forms;

public class TestForm3Driver {
  static void Main() {
    // The Main() method has become quite simple,
    // just call the Run() method.
    Application.Run(new TestForm3());
  }
}
